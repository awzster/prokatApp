angular.module('toolRentalApp', [])
    .config(function($interpolateProvider) {
        //$interpolateProvider.startSymbol('{[{').endSymbol('}]}');
    });
